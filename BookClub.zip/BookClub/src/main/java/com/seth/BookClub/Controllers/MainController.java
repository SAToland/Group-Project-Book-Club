package com.seth.BookClub.Controllers;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.seth.BookClub.Models.Book;
import com.seth.BookClub.Models.LoginUser;
import com.seth.BookClub.Models.User;
import com.seth.BookClub.Services.BookService;
import com.seth.BookClub.Services.UserService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
public class MainController {

	@Autowired
	UserService uServ;
	@Autowired
	BookService bServ;
	
	@PostMapping("/register")
	public String register(@Valid @ModelAttribute("newUser") User newUser,
	                       BindingResult result, Model model, HttpSession session) {
	    
	    uServ.register(newUser, result);
	    
	    if(result.hasErrors()) {
	        model.addAttribute("newLogin", new LoginUser());
	        return "index.jsp";
	    }
	    // Retrieve the registered user and add the user ID to the session
	    User registeredUser = uServ.findUserByEmail(newUser.getEmail());
	    session.setAttribute("isLogged_in", true);
	    session.setAttribute("userId", registeredUser.getId()); // Storing user ID in the session
	    session.setAttribute("email", registeredUser.getEmail()); // Optional if needed

	    return "redirect:/home";
	}
	
	@PostMapping("/login")
	public String login(@Valid @ModelAttribute("newLogin") LoginUser newLogin,
	                    BindingResult result, Model model, HttpSession session) {
	    
	    User loggedInUser = uServ.login(newLogin, result);
	    
	    if(result.hasErrors()) {
	        model.addAttribute("newUser", new User());
	        return "redirect:/";
	    }
	    // Adds isLogged_in and user ID to session
	    session.setAttribute("userId", loggedInUser.getId()); // Storing user ID in the session

	    return "redirect:/home";
	}
	
	
	@GetMapping("/")
	public String index(Model model, HttpSession session) {
		
		model.addAttribute("newUser", new User());
		model.addAttribute("newLogin", new LoginUser());
		return "index.jsp";
	}
	
	@GetMapping("/home")
	public String home(@ModelAttribute("user") User user, @ModelAttribute("newBook") Book book
			, Model model, HttpSession session) {
		String cUser = (String) session.getAttribute("email");
		List<User> users = uServ.allUsers();
		List<Book> books = bServ.findAll();
		User currentUser = uServ.findUserByEmail(cUser);
		
		model.addAttribute("cUser", currentUser);
		model.addAttribute("books", books);
		model.addAttribute("users", users);
		return "home.jsp";
	}
	
	@GetMapping("/create")
	public String create(@ModelAttribute("newBook") Book book, Model model, HttpSession session) {
	    // Check if the user is logged in
	    if(session.getAttribute("isLogged_in") == null || session.getAttribute("userId") == null) {
	        return "redirect:/";
	    }

	    // Retrieve the logged-in user's ID from the session
	    Long userId = (Long) session.getAttribute("userId");
	    User currentUser = uServ.findById(userId); // Ensure uServ has a findUserById method

	    // Associate the book with the logged-in user
	    book.setUser(currentUser); // Assuming Book model has a 'User user' field

	    // Add necessary attributes for the JSP
	    model.addAttribute("cUser", currentUser);
	    return "create.jsp";
	}

	
	@GetMapping("/view/{id}")
	public String view(Model model, @PathVariable("id") Long id, HttpSession session) {
		Book thisbook = bServ.findById(id);
		User postUser = thisbook.getUser();
		// Checks if user is logged in to stop users that aren't logged in from accessing page
		if(session.getAttribute("isLogged_in") == null) {
			return "redirect:/";
		}
		model.addAttribute("pUser", postUser);
		model.addAttribute("book", thisbook);
		return "view.jsp";
	}
	
	@PostMapping("/addBook")
	public String addBook(@Valid @ModelAttribute("newBook") Book book,
			BindingResult result, Model model, HttpSession session) {
		
		if(result.hasErrors()) {
			model.addAttribute("newBook", new Book());
			return "index.jsp";
		}
		
		bServ.createBook(book);
		return "redirect:/home";
	}
	
	
	@PostMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
	
	@GetMapping("/edit/{id}")
	public String editBook(@PathVariable("id") Long id, Model model, HttpSession session) {
	   

	    // Retrieve the book by ID
	    Book book = bServ.findById(id);
	    if (book == null) {
	        return "redirect:/home";
	    }

	    // Retrieve the logged-in user's ID from the session
	    Long userId = (Long) session.getAttribute("userId");

	    // Check if the logged-in user is the creator of the book
	    if (!book.getUser().getId().equals(userId)) {
	        return "redirect:/home";
	    }

	    // Add the book to the model to populate the form fields in the JSP
	    model.addAttribute("newBook", book);
	    
	    // Add current user info to the model if needed in JSP
	    User currentUser = uServ.findById(userId);
	    model.addAttribute("cUser", currentUser);

	    return "update.jsp"; // This should be the name of your JSP file that handles updates
	}


	
	@PostMapping("/updateBook")
	public String updateBook(@Valid @ModelAttribute("newBook") Book book,
	                         BindingResult result, Model model, HttpSession session) {
	   

	    if (result.hasErrors()) {
	        Long userId = (Long) session.getAttribute("userId");
	        User currentUser = uServ.findById(userId);
	        model.addAttribute("cUser", currentUser);
	        return "edit.jsp";
	    }

	    // Set the current user as the book's user before updating
	    Long userId = (Long) session.getAttribute("userId");
	    User currentUser = uServ.findById(userId);
	    book.setUser(currentUser);

	    // Update the book details
	    bServ.updateBook(book);

	    return "redirect:/home";
	}
	
	@PostMapping("/delete/{id}")
	public String deleteBook(@PathVariable("id") Long id, HttpSession session) {
	    

	    // Find the book by ID
	    Book book = bServ.findById(id);
	    if (book == null) {
	        return "redirect:/home";
	    }

	    // Check if the logged-in user is the creator of the book
	    Long userId = (Long) session.getAttribute("userId");
	    if (!book.getUser().getId().equals(userId)) {
	        return "redirect:/home";
	    }

	    // Delete the book
	    bServ.deleteBook(id);
	    return "redirect:/home";
	}
}
